export default class Item {
  constructor(id, type, name, desc, imgSrc_jpg, imgSrc_png) {
    this.id = id;
    this.type = type;
    this.name = name;
    this.desc = desc;
    this.imgSrc_jpg = imgSrc_jpg;
    this.imgSrc_png = imgSrc_png;
  }
}
