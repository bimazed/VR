import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div>
        <div>
          <hr className="style13" />
          <div className="card hovercard">
            <div className="card-info">
              {" "}
              <span className="card-title">
                @Copyright 2019 - Huynh Xuan Oanh
              </span>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
